/* Clase que conecta aplicación con BD */
package ConexionBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConectaBD {
    public static Connection initializeDatabase()
            throws SQLException,ClassNotFoundException {
         
        String host = "localhost";
        String puerto = "3306";
        String usuario = "root";
        String password = "";
        String bd = "sin_bd";
        String url = "jdbc:mysql://" + host + ":"+puerto+"/"+ bd +"?user=" + usuario + "&password=" + password;
    
        Connection con = DriverManager.getConnection(url);
        
        return con;
    }
}
