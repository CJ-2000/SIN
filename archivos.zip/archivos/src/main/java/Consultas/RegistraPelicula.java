package Consultas;

import ConexionBD.ConectaBD;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistraPelicula extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            /*información para registrar proviene de un form en registro.jsp*/
            String nombre = request.getParameter("nom_ins");
            String desc = request.getParameter("desc_ins");
            String codigo = request.getParameter("cod_ins");
            
            Connection con = ConectaBD.initializeDatabase();
            Statement stmt =con.createStatement();  
            
            int filas = stmt.executeUpdate("INSERT INTO peliculas (nombre,descripcion,codigo) "
                    + "VALUES ( '" + nombre + "','" + desc + "','" + codigo +"'   )") ;
            
            
            if (filas > 0 ) {
                /*Lanza una alerta en javascript*/
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Registro completo');");
                out.println("location='jsp/registro.jsp';");
                out.println("</script>");
            } else {
                
                /* retorna respuesta: tabla */
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Error. No se pudo registrar');");
                out.println("location='jsp/registro.jsp';");
                out.println("</script>");
            }
            /* termina la conexión de BD */
            con.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
