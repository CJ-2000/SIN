/* Servelt interactúa con formulario y muestra salida */
package Consultas;

import ConexionBD.ConectaBD;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ListarPeliculas", urlPatterns = {"/ListarPeliculas"})
public class ListarPeliculas extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            Connection con = ConectaBD.initializeDatabase();
            Statement stmt =con.createStatement();            
            ResultSet rs= stmt.executeQuery("SELECT * FROM peliculas");
             
            /* retorna respuesta: tabla */
            out.println("<table border = 1 width=50% height = 50%>");
            out.println("<tr><th>Id</th><th>Codigo</th><th>Pelicula</th><th>Detalle</th><tr>");

            while (rs.next()){
               int n = rs.getInt("id");
                String cod = rs.getString("codigo");
                String nm = rs.getString("nombre");
                String s = rs.getString("descripcion");
                out.println("<tr><td>" + n + "</td><td>" + cod + "</td><td>" + nm +"</td><td>" + s + "</td><tr>");                    
            }
            out.println("</table>");            
            out.println("</html> <input type=\"button\" value=\"Volver\" onclick=\"location.href='jsp/menu.jsp';\" /> </body>");

            /* termina la conexión de BD */
            con.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
