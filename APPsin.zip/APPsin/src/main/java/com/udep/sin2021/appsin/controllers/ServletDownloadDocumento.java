/* Capa Controllers:*/
// Captura parámetros

package com.udep.sin2021.appsin.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDownloadDocumento extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        // Extrae parámetro "nombre" del archivo desde la tabla anterior. Ejemplo: "documento.xlsx"
        String nombre_archivo = request.getParameter("nombre"); 
        // Ruta de la carpeta destino donde se va a descargar el archivo
        String ruta_destino = "d:/aplicacion/"; 

        // Package Utilitys, clases con constantes como "rutas"
        // iReport crea reportes (jasperreports) : template->BD / jxrml (plantilla) dentro de carpeta wildfly/ 
        // Llamar a la plantilla con servlet
        
        // reportes: índice de documentos solicitados
        
        
        try (PrintWriter out = response.getWriter()) {
            // Esta clase ya existe y se invoca desde la librería Files
            File f = new File(ruta_destino + nombre_archivo);
            
            // Primero se verifica de que exista el archivo
                if(f.exists() && !f.isDirectory()) { 
                    // En caso de que exista descarga el archivo
                    
                    // Establece el tipo de archivo de manera general. Ejemplo: Para imagen sería ("image/png")
                    response.setContentType("APPLICATION/OCTET-STREAM");  
                    // Solo guarda el archivo, no lo va a mostrar
                    response.setHeader("Content-Disposition","attachment; filename=\"" + nombre_archivo + "\"");   
                    
                    FileInputStream fileInputStream = new FileInputStream(ruta_destino + nombre_archivo);  
                    int i;   
                    while ((i=fileInputStream.read()) != -1) {  
                    out.write(i);   
                    }   
                    fileInputStream.close();   
                    out.close();   
                }  else{
                    // En caso de que NO exista el archivo, se lanza una alerta
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('El archivo no existe');");
                    out.println("location='index.jsp';");
                    out.println("</script>");
                }  
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
